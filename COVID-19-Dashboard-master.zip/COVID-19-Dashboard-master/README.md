# COVID-19_TRACKER HTML5 CSS3 JAVASCRIPT
Interesting part is that I have implemented lazy loading here using Vanilla JS in a simple manner
